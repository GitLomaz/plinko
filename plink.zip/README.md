# plinko
### version 0.1.6
A simple HTML5 Canvas game made with Phaser and an HTML UI, click on balls to get score!
